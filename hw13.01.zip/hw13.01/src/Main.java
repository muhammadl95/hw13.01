public class Main {
    public static void main(String[] args) {

        String firstHomeWork;

        final int NUM = 17;
        System.out.println(NUM);

        String word = "years";
        System.out.println(word);

        firstHomeWork = (NUM + " " + word);
        System.out.println(firstHomeWork);

        System.out.println(firstHomeWork + " " + word);

        if (NUM < 0) {
            System.out.println("Вы сохранили отрицательное число");
        } else if (NUM > 0) {
            System.out.println("Вы сохранили положительное число");
        } else {
            System.out.println("Вы сохранили ноль");
        }

        System.out.println("Введите ваше имя:");

        System.out.println("Мухаммад");

        System.out.println("Здравствуйте " + "Мухаммад!");

    }
}